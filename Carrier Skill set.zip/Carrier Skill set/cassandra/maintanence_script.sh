#!/bin/bash
set -e
# Older Cassandra insalls use 8080, noewer ones use 7199.
jmxPort=7199

#Get container Ip
IP=`hostname --ip-address`

checkForNodetool() {
  if [ ! -x /usr/bin/nodetool ]; then
    echo "nodetool not found."
    exit 1
  fi
}

clearsnapshots() {

#start cassandra
cassandra -R
sleep 25

#Clear all the snapshot
set -x
nodetool -h $IP -p $jmxPort clearsnapshot
result="$?"
 if [ "$result" != 0 ]; then
    echo "Your command exited with non-zero status $result"
    else
    echo "Snapshots have been cleared"
fi
set +x
}

kill(){

pkill -f CassandraDaemon

}