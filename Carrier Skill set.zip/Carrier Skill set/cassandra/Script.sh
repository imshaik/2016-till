#!/bin/bash

host=vmlnxdbcass04 ####hostname
cass_query="$@"
keyspace="use pricing;" ###define your keyspace
echo "$cass_query;"
echo "$keyspace"
echo "$host"

result=$(cqlsh -u 'c8024524' -p 'April@!991' $host -e "$keyspace$cass_query" )
echo $result