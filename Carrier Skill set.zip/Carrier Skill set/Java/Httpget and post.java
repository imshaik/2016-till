import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
//import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.client.methods.HttpUriRequest;

import org.junit.Assert;
//import static org.junit.Assert.assertArrayEquals; ##when you enable this no need to mention Assert.assertEquals,,,Just say assertEquals(....)
//import org.junit.Ignore; ##to ginore the test at class level should be above public class  or method level like below
//@Ignore("message")
@Test
        //@DisplayName("Test case is to verify whether environment is accessible or not ")
        public void testExecute() throws IOException  {
            try {
                HttpClient   httpClient    = HttpClientBuilder.create().build();
                HttpPost  httpPost = new HttpPost("https://lwscomsit4.lowes.com");
                //HttpGet request = new HttpGet("http://lwscomsit4.lowes.com");
                //HttpUriRequest httpUriRequest = new HttpGet("https://lwscomsit4.lowes.com");
                HttpResponse response = httpClient.execute(httpPost);
				httpClient.getConnectionManager().shutdown();
                /*Assert.assertNotNull(service.execute(new HttpPost("http://www.lowes.com"))); */
                Assert.assertNotNull(response);
                //System.out.println("Statusline: " + response.getStatusLine());
                //System.out.println("Status Code is: " + response.getStatusLine().getStatusCode());
                Assert.assertEquals(200, response.getStatusLine().getStatusCode());
            }
            catch (Exception e) {
                System.out.println("Caught an exception" + e.getMessage().toString());
             }
        }
}
     