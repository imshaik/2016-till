#!/bin/bash
 
TAG=$1
ENV=$2
NEXUS=http://vmlnxbandd.lowes.com/nexus/content/repositories/releases/com/lowes
ARTIFACT=$3
ARTIFACT_URL=$NEXUS/$ARTIFACT/$TAG/$ARTIFACT-$TAG.tar.gz
 
# Validate Parameters.
if [ -z ${1+x} ] || [ -z ${2+x} ] || [ -z ${3+x} ]; then
  echo "Please provide a valid tag, environment and artifact."
  echo "USAGE: $0 TAG ENVIRONMENT"
  exit 1
fi

# Remove directory if exists.
echo "Deleting old artifact directory."
rm -rf $ARTIFACT/
echo "$ARTIFACT folder deleted"

# Request artifact from Nexus.
echo "Making source directory and unzipping TAR from nexus."
mkdir -p $ARTIFACT/source && wget -q "$ARTIFACT_URL" -O - | tar -xz -C $ARTIFACT/source

#Go into the respective artifact directory
cd $ARTIFACT/
echo "Current path is : $PWD"

#Move enviornment JSON to 'source'
cp source/ecosystem/$ENV.json source/$ENV.json
echo "JSON copied to source dir."

# Start the application via PM2 process manager.
cd source/
echo "Current path is : $PWD"
pm2 startOrRestart $ENV.json --env $ENV && echo 'flush_all' | nc localhost 11211 && echo 'stats reset' | nc localhost 11211