
org_admin_password_reset(){

underline=`tput smul`
bold=`tput bold`
normal=`tput sgr0`

read -p " Enter the username : " user

. /home/db2inst1/sqllib/db2profile
db2 list db directory &>/dev/null
db2 list node directory &>/dev/null
echo " CONNECTING TO DB -- $DB_NAME "
db2 connect to $DB_NAME user WCSPROLN using @pr04apr &>/dev/null
db2 set schema wcsproln &>/dev/null

userID=`db2 -x  " select USERS_ID from userreg where LOGONID = '$user'"`
echo $loginId
if [ -z "$userID" ];
then
   echo " No  Loginid found with user $user"
else
   echo " Resetting the password for $user"
   db2 -x " update userreg set LOGONPASSWORD = x'4a682b2b58335633796e77364e746f312b32685859726462716277494a4e6255475834596b466c5a3539513d202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020',STATUS=1,SALT ='ee8gr9z394t3' where LOGONID = '$user' and USERS_ID = $userID"
  echo " Resetted password"
  echo " plase use the password is ${underline}${bold}passw0rd${normal} for user $user"
fi 

echo " press any key to continue"
read


}

### Author Venkatesh Juluir
#$ force_JVM_Stop : For forcefully killing JVM in Application Server

force_JVM_Stop(){
echo " 1. Stop JVM-A"
echo " 2. Stop JVM-B"
echo " 3. Stop Both JVM's"
echo " 4. Stop JVM with Process ID"

read -p " Enter Your Choice " option

JVMA_Log_Path="/lowes/WebSphere/WAS/V7/AppServer/profiles/lwsecom/logs/LWSECOMSRV1_A"
JVMA_Pid=`echo $JVMA_Log_Path | awk -F '/' '{print $(NF)}'`.pid
JVMB_Log_Path="/lowes/WebSphere/WAS/V7/AppServer/profiles/lwsecom/logs/LWSECOMSRV1_B"
JVMB_Pid=`echo $JVMB_Log_Path | awk -F '/' '{print $(NF)}'`.pid
#echo "test"$JVMA_Pid
#cat $JVMA_Pid

if [ $option -eq 1 ];then
   echo $ENVHOST
   echo "pid is "$pid
#id=$(ssh $ENVHOST " ps -ef | grep lwc | grep LWSECOMSRV1_A | awk {'print $2'} | head -1 " )
#id=`ssh -t $ENVHOST " ps -ef | grep lwc | grep LWSECOMSRV1_A | awk {'print $2'} | head -1 "`
   pid=$(ssh -t $ENVHOST " cd $JVMA_Log_Path ; cat LWSECOMSRV1_A.pid")
   echo "pid is "$pid
#spid=$(echo $pid | cut -d "" -f2)
#pid=`echo $id | awk '{print $2}'` 
#pid=`echo $id | awk '{print $2}'`
#echo "pid is " $pid
   echo " killing JVM A"
   ssh -t $ENVHOST " kill -9 $pid"
   echo " Killed JVM A"
else if [ $option -eq 2 ];then
#id=$(ssh -t $ENVHOST "ps -ef | grep lwc | grep LWSECOMSRV1_B | awk {'print $2'} | head -1 ")
#pid=`echo $id | awk '{print $2}'`
   pid=$(ssh -t $ENVHOST " cd $JVMB_Log_Path ; cat LWSECOMSRV1_B.pid")
   echo "pid is "$pid
   echo " killing JVM B"
   ssh -t $ENVHOST " kill -9 $pid"
   echo " Killed JVM B"
else if [ $option -eq 3 ];then
#JVMA_id=$(ssh -t $ENVHOST "ps -ef | grep lwc | grep LWSECOMSRV1_A | awk {'print $2'} | head -2 ")
#JVMB_id=$(ssh -t $ENVHOST "ps -ef | grep lwc | grep LWSECOMSRV1_B | awk {'print $2'} | head -1 ")
#JVMA_pid=`echo $JVMA_id | awk '{print $2}'`
   JVMA_pid=$(ssh -t $ENVHOST " cd $JVMA_Log_Path ; cat LWSECOMSRV1_A.pid")
#JVMB_pid=`echo $JVMB_id | awk '{print $2}'`
   JVMB_pid=$(ssh -t $ENVHOST " cd $JVMB_Log_Path ; cat LWSECOMSRV1_B.pid")
   echo "pid is " $JVMA_pid
   echo "apid " $JVMB_pid
   ssh -t $ENVHOST " kill -9 $JVMA_pid $JVMB_pid"
else if [ $option -eq 4 ];then
   read -p "Enter the process id " pid
   echo " killing pid"
   ssh $ENVHOST " kill -9 $pid "
   echo " killed "
fi fi fi fi
echo " Presss any key to continue.......  "
read
}

### masterOrder_Updation : Generates csv file with provided statting and end number and import the csv file into 
### respective DB

masterOrder_updation(){

read -p "Enter start Number of Master order Number " init_Master_Order_Num
read -p " Enter the End Number of Master order " end_Master_Order_Num

seq $init_Master_Order_Num $end_Master_Order_Num > MasterOrder.csv
sed -i 's/$/,0,1/' MasterOrder.csv

chmod 777 MasterOrder.csv

echo " DB ENVIRONMENT SETUP - START" 
. /home/db2inst1/sqllib/db2profile
db2 list db directory &>/dev/null
db2 list node directory &>/dev/null
echo " DB ENVIRONMENT SETUP - COMPLETED "

echo " DBName is " $DB_NAME

echo " Connecting to Database "$DB_NAME
db2 connect to $DB_NAME user WCSPROLN using @pr04apr &>/dev/null
db2 set schema wcsproln &>/dev/null
echo " Connected to Database " $DB_NAME
db2 -x "select count(*) from T5757_LWS_MAS_ORD "
echo " Do You Want to delete existing records from Master Order table (Y/N) "
read delete_Option
if [ "$delete_Option" == 'Y' ] || [ "$delete_Option" == 'y' ];
then
    echo " Deleting Existing Master Order Number from Master Order Table "
    db2 -x " delete from T5757_LWS_MAS_ORD "
    echo " Mater order NUmbers are deleted "
fi

echo "Inserting Master number"
db2 -x " import from MasterOrder.csv of del insert into T5757_LWS_MAS_ORD "
echo " Inserted Master Number in $DB_NAME"
db2 'DISCONNECT CURRENT'
echo " Presss any key to continue.......  "
read
}

removeHeapfile(){

read -p " Enter How many old days files You want to delete : " days
FILE=/tmp/heapTemp.txt
rm /tmp/heapTemp.txt
profile_Directory="/lowes/WebSphere/WAS/V7/AppServer/profiles/lwsecom/"
#ENV_NAME=`sed -n '1p' <DCS.properties | cut -f1 -d ','`
#ENV_HOST=`sed -n '1p' <DCS.properties | cut -f2 -d ','`

echo $ENV_NAME
echo $ENVHOST

echo "Searching heap dump files"
#ssh $ENV_HOST " find $profile_Directory -iname "javacore*" -type f -mtime +$days -ls 2>/dev/null" > /tmp/heapTemp.txt
#ssh $ENV_HOST " find $profile_Directory -type f\(-name "javacore*" -o -name "heapdump*"\) -mtime +$days -ls 2>/dev/null" > /tmp/heapTemp.txt
ssh $ENVHOST " find $profile_Directory -type f \( -name 'javacore*' -o -name 'heapdump*'  \) -mtime +$days -ls 2>/dev/null" > /tmp/heapTemp.txt
#ssh $ENVHOST " find /lowes/WebSphere/WAS/V7/AppServer/profiles/lwsecom/ -type f\(-name "javacore*" -o -name "heapdump*"\) -mtime +$days -ls 2>/dev/null" > /tmp/heapTemp.txt
cat $FILE
if [ ! -s $FILE ];then
   echo " No JAVACORE AND HEAPDUMP Files are present in $ENV_NAME Environment with $days days "
else
   read -p " Please confirm Do you want to Delete Above files (Y/N) " option
   if [ "$option" == 'Y' ] || [ "$option" == 'y' ];
     then
        filename=`cat $FILE | awk -F '/' '{ print $(NF)}'`
        echo " changing the permission of the $profile_Directory"
        ssh -t $ENVHOST " sudo -u root /home/lwc/scripts/changeperm-lwc.sh $profile_Directory"
        echo " Changed Permissions of the $profile_Directory"
        echo " Deleting javacore and Heapdump files from $ENV_NAME"
        for line in $filename
          do
            path=$line
          #filename=`cat $FILE | awk -F '/' '{ print $(NF)}'`
          #filename=`awk -F "\t" '{print $NF}' $FILE`
            echo $path
            #ssh -t $ENVHOST " sudo -u root /home/lwc/scripts/changeperm-lwc.sh $profile_Directory"
            ssh -t $ENVHOST " cd $profile_Directory ; rm $path" 2>/dev/null
          done
        echo " Deleted javacor and HeapDump files from $ENV_NAME"
      else
          echo " skipping file deletion "
     fi
fi
#echo $filename
echo " Presss any key to continue.......  "
read
}

clearCache(){

cacheA_directory=/lowes/WebSphere/WAS/V7/AppServer/profiles/lwsecom/temp/lwsecom_node1/LWSECOMSRV1_A/WC_lwsecom/Stores.war/B2BDirectStorefrontAssetStore
cacheB_directory=/lowes/WebSphere/WAS/V7/AppServer/profiles/lwsecom/temp/lwsecom_node1/LWSECOMSRV1_B/WC_lwsecom/Stores.war/B2BDirectStorefrontAssetStore
echo $appserver_directory
echo " clearing cache initiated "
#test=sed -n 1p DCS.properties
#. /lowes/DCS.properties
#ENV_NAME=`sed -n '1p' <DCS.properties | cut -f1 -d ','`
#ENV_HOST=`sed -n '1p' <DCS.properties | cut -f2 -d ','`
echo $ENV_NAME
echo $ENVHOST

#test=$1
echo $ENV_NAME

echo " connecting to " $ENV_NAME
echo $ENVHOST
echo " PERMISSION SCRIPT -- START "
ssh -t $ENVHOST 'sudo -u root /home/lwc/scripts/changeperm_global.sh'
echo " PERMISSION SCRIPT -- END "

#ssh -t $ENV_HOST " cd $cache_directory; "
read -p " Do You want to Clear Cache in JVM-A : please confirm (Y/N)" option

if [ "$option" == 'Y' ] || [ "$option" == 'y' ];
then
    echo " Clearing Cache in JVM-A "
    ssh -t $ENVHOST "cd $cacheA_directory; rm -r *"
    echo " Cleared Cache in JVM-A"
else
    echo "skipping JVM-A cache clearing"
fi

read -p " Do You want to Clear Cache in JVM-B : Please confirm (Y/N)" option
if [ "$option" == 'Y' ] || [ "$option" == 'y' ];
then
    echo " Clearing Cache in JVM-B "
    ssh -t $ENVHOST "cd $cacheB_directory; rm -r *"
    echo " Cleared Cache in JVM-B"
else
   echo "skipping JVM-B cache clearing"
fi

echo " clearing cache completed "
echo " Presss any key to continue.......  "
read
}

storeSetupMenu(){ 

echo " *************************************************"
echo "                STORE SETUP MENU      "
echo " *************************************************"

echo " 1. New Store Setup "
echo " 2. Address Changes "
echo " 3. Return to Previous Menu"
echo " 4. EXIT"

}

read_storeSetup_Options(){

read -p " Enter Your Choice " option

case $option in
    [1-2])storeSetup;;
    3)return 1;;
    4)exit 0;;
esac

}

show_storeSetupMenu(){

while true
do
clear
storeSetupMenu
read_storeSetup_Options
if [[ $? == 1 ]]; then
break
fi
done
}

storeSetup(){

count=0

cd /lowes

echo " store setup display"
echo " DB ENVIRONMENT SETUP - START" 
. /home/db2inst1/sqllib/db2profile
db2 list db directory &>/dev/null
db2 list node directory &>/dev/null
echo " DB ENVIRONMENT SETUP - COMPLETED "

echo " CONNECTING TO DB -- $DB_NAME "
#DB_Name=`sed -n '1p' <DCS.properties | cut -f3 -d ','`
echo $DB_NAME
db2 connect to $DB_NAME user WCSPROLN using @pr04apr &>/dev/null
db2 set schema wcsproln &>/dev/null

read -p " Enter the Number of Stores to setup : " store_Count

while [ $count -lt $store_Count ]
do

  clear

  echo " CONNECTED TO DB - $DB_NAME "
  read -p " Enter the production Store number  : " prod_Store
  read -p " Enter the Test Store Number        : " test_Store
  read -p " Enter the Zipcde                   : " zipcode
  read -p " Enter the Address                  : " address
  read -p " Enter the City                     : " city
  read -p " Enter the State                    : " state

  address2=`echo $address | sed "s/'/\''/g"`
  echo "address 2 is " $address2

  #db2 -x  " select * from WCSPROLN.E286_LCT_ZIP_CFR where T063_LCT_NBR = $pstore and DCE_TO_CTR_AMT = 0"
  echo -e " \n"
  db2 -x " UPDATE E286_LCT_ZIP_CFR SET DCE_TO_CTR_AMT =100 Where E285_ZIP_CD = $zipcode and DCE_TO_CTR_AMT = 0"
  echo -e " ###### STORE SETUP FOR $test_Store -- START \n "
  echo " Exporting CSV file from $prod_Store"

  db2 -x " export  to /tmp/$test_Store.csv of del  select * from WCSPROLN.E286_LCT_ZIP_CFR where T063_LCT_NBR = $prod_Store order by DCE_TO_CTR_AMT" &>/dev/null
  chmod 777 /tmp/$test_Store.csv
  store_Rows=`wc -l < /tmp/$test_Store.csv`
  echo " Exported CSV file from $prod_Store with ROWS $store_Rows"

  sed -i "s/$prod_Store/$test_Store/g" /tmp/$test_Store.csv 

  echo " Deleting Existing $test_Store details in Table - E286_LCT_ZIP_CFR"
  db2 -x " delete from E286_LCT_ZIP_CFR where T063_LCT_NBR = $test_Store " &>/dev/null
  echo " Deleted $test_Store in Table - E286_LCT_ZIP_CFR"

  echo " "

  echo " Import Started for Store : $test_Store"
  #db2 -x " import from /tmp/$test_Store.csv of del insert into WCSPROLN.E286_LCT_ZIP_CFR " &>/dev/null
  db2 -x " import from /tmp/$test_Store.csv of del insert into WCSPROLN.E286_LCT_ZIP_CFR " &>/dev/null
  echo " Import is completed for Store : $test_Store with ROWS : $store_Rows "

  db2 -x " UPDATE E286_LCT_ZIP_CFR SET DCE_TO_CTR_AMT = 0 Where E285_ZIP_CD = $zipcode and T063_LCT_NBR = $test_Store " &>/dev/null
  #test_Zipcode=`db2 -x " SELECT T063_LCT_NBR  FROM E286_LCT_ZIP_CFR WHERE E285_ZIP_CD = $zipcode AND DCE_TO_CTR_AMT = 0 ORDER BY T063_LCT_NBR" `
  data=`db2 -x " SELECT * FROM E286_LCT_ZIP_CFR WHERE E285_ZIP_CD = $zipcode AND DCE_TO_CTR_AMT = 0 ORDER BY T063_LCT_NBR "`

  db2 -x " delete from T063A_LCT where T063_LCT_NBR = $test_Store "
  echo " Exporting $prod_Store details from T063A_LCT "
  db2 -x " export to /tmp/$test_Store_T063A_LCT.csv of del select * from T063A_LCT where T063_LCT_NBR=$prod_Store " &>/dev/null
  echo " Exported $prod_Store details from T063A_LCT" 
 
  echo " updating the TABLE T063A_LCT with TEST Store : $test_Store "  
  db2 -x " import from /lowes/testAddress.csv of del insert into T063A_LCT " &>/dev/null
  db2 -x " update T063A_LCT set T063_LCT_NBR = $test_Store,BUS_NME='LOWES TEST STORE-$test_Store',DLV_ADR='$address2',DLV_CTY_NME='$city',DLV_ST_CD='$state',DLV_ZIP_CD=$zipcode,MAL_CTY_NME='$city',MAL_ST_CD='$state',MAL_ZIP_CD=$zipcode,CNY_NME='$city',MAL_POT_CD='$zipcode',DLV_POT_CD='$zipcode' WHERE T063_LCT_NBR = 12345"
  echo " Updated the TABLE T063A_LCT with TEST Store : $test_Store " 
  count=`expr $count + 1` 
  echo "count " $count
  echo $store_Count
	
  echo "deleting records greater than 75 miles"
  db2 -x " delete from E286_LCT_ZIP_CFR where T063_LCT_NBR=$test_Store and DCE_TO_CTR_AMT>=75.00"

done

db2 'DISCONNECT CURRENT'

echo " Presss any key to continue.......  "
read

}

giftcard_nvalue_change(){

ext_nValue_length=0
uptd_nValue_length=0

#echo " Fetching mobile-min.js and MobileWebServiceLocator files from $ENV_NAME -- START "
#scp ${IHSHOST}:${MOBILE_MIN_PATH}/mobile-min.js /tmp/mobile-min.js
#scp -r ${IHSHOST}:${MOBILE_SERVICELOCATOR_PATH}/MobileWebServiceLocator$ENV_NAME.json /tmp/MobileWebServiceLocator$ENV_NAME.json
#scp -r ${IHSHOST}:${MOBILE_MIN_PATH}/mobile-min.js /tmp/mobile-min.js

#echo " Fetching mobile-min.js and MobileWebServiceLocator files from $ENV_NAME -- COMPLETED"

#echo " Change of file permission -- START"
#chmod 755 /tmp/MobileWebServiceLocator$ENV_NAME.json
#chmod 755 /tmp/mobile-min.js
#echo " Change of File Permission - COMPLETED"

while [[ $ext_nValue_length != 10 ]];do

    read -p " Enter the existing nValue in $ENV_NAME  :  " ext_nValue
    ext_nValue_length=${#ext_nValue}
    
    if [ $ext_nValue_length != 10 ]; then
       echo " Enterted NValue is not Correct please enter the correct nValue"
    fi
done

while [[ $uptd_nValue_length != 10 ]];do
    read -p " Enter the correct nValue for $ENV_NAME  :  " uptd_nValue
    uptd_nValue_length=${#uptd_nValue}
    if [ $uptd_nValue_length != 10 ]; then
        echo " nValue should have 10 digits Please Enter the correct nValue "
    echo $uptd_nValue_length
    fi
done

echo " Fetching mobile-min.js and MobileWebServiceLocator files from $ENV_NAME -- STARTED "
scp -r ${IHSHOST}:${MOBILE_SERVICELOCATOR_PATH}/MobileWebServiceLocator$ENV_NAME.json /tmp/MobileWebServiceLocator$ENV_NAME.json
scp -r ${IHSHOST}:${MOBILE_MIN_PATH}/mobile-min.js /tmp/mobile-min.js
echo " Fetching mobile-min.js and MobileWebServiceLocator files from $ENV_NAME -- COMPLETED"

echo " Changing  mobile-min.js and MobileWebServiceLocator File permissions -- START"
chmod 775 /tmp/MobileWebServiceLocator$ENV_NAME.json
chmod 775 /tmp/mobile-min.js
echo " Changing  mobile-min.js and MobileWebServiceLocator File Permission - COMPLETED"

#scp -r /tmp/MobileWebServiceLocator$ENV_NAME.json ${IHSHOST}:${MOBILE_SERVICELOCATOR_PATH}/MobileWebServiceLocator$ENV_NAME.json
#scp -r /tmp/mobile-min.js ${IHSHOST}:${MOBILE_MIN_PATH}/mobile-min.js

echo " Updating the mobile-min.js and MobileWebServiceLocator with with correct nValue - STARTED "
sed -i "s/$ext_nValue/$uptd_nValue/g" /tmp/MobileWebServiceLocator$ENV_NAME.json
sed -i "s/$ext_nValue/$uptd_nValue/g" /tmp/mobile-min.js
echo " Updating the mobile-min.js and MobileWebServiceLocator with with correct nValue - COMPLETED "

echo " Pushing the mobile-min.js and MobileWebServiceLocator files to $ENV_NAME - STARTED"

scp -r /tmp/MobileWebServiceLocator$ENV_NAME.json ${IHSHOST}:${MOBILE_SERVICELOCATOR_PATH}/MobileWebServiceLocator$ENV_NAME.json
scp -r /tmp/mobile-min.js ${IHSHOST}:${MOBILE_MIN_PATH}/mobile-min.js

echo " Pushing the mobile-min.js and MobileWebServiceLocator files to $ENV_NAME - COMPLETED"

read -p " JSON and JS file updation is completed in $ENV_NAME: Press any Key to initiate ihsmanager_global.sh to  restart webserver " start

sudo -u lwc /home/lwc/scripts/ihsmanager_global.sh
read -p " nValue change for Gift cards is completed, Please do Akamai flush  and press any key to return to Main Menu " key
}



environment_SubMenu(){

clear
echo " ENVIRONMENT NAME - $ENV_NAME "
echo " ***************************************************"
echo " 1. Clear Cache "
echo " 2. Store Setup "
echo " 3. Delete HeapDump and Java Core files"
echo " 4. MaterOrder number updation "
echo " 5. Force JVM STOP "
echo " 6. Org-ADMIN User password Reset "
echo " 7. Gift Card nValue Change "
echo " 8. Return to Previous Screen "
echo " 9. Exit "
echo " ***************************************************"

}

read_SubMenu_options(){
read -p " Enter Your Choice " option

case $option in
    1)clearCache;;
    2)show_storeSetupMenu;;
    3)removeHeapfile;;
    4)masterOrder_updation;;
    5)force_JVM_Stop;;
    6)org_admin_password_reset;;
    7)giftcard_nvalue_change;;
    8)return 1;;
    9)exit 0;;
esac
}
setEnvironment(){

#Reset environment Varialbes
DB_NAME=""
ENVVAR=""
ENVHOST=""
ENV_DETAILS=""
IHSHOST=""
IHS_PATH="/lowes/IHS/V70A"
ENVVAR=""
CONFPATH="/lowes/IHS/V70A/conf/"
MOBILE_SERVICELOCATOR_PATH="/lowescontent/B2BDirectStorefrontAssetStore/mobile/web/"
MOBILE_MIN_PATH="/lowescontent/B2BDirectStorefrontAssetStore/mobile/web/js/"


ENV_DETAILS=`awk "NR==$MAIN_VAR" /lowes/DCS.properties`
ENV_NAME=$(echo $ENV_DETAILS | cut -f1 -d ",")
echo "Environment detials" $ENV_DETAILS
DB_NAME=$(echo $ENV_DETAILS | cut -f3 -d ",")
echo " DB Name " $DB_NAME
ENVHOST=$(echo $ENV_DETAILS | cut -f2 -d ",")
echo " Appserver " $ENVHOST
IHSHOST=$(echo $ENV_DETAILS | cut -f4 -d ",")
echo "IHS is " $IHSHOST
ENVVAR=$(echo $ENV_DETAILS | cut -f5 -d ",")
echo $ENVVAR


SRVCHK=`nc -z -w 2 ${ENVHOST} 22 |wc -l`

if [ ${SRVCHK} -eq 1 ]; then
	environment_SubMenu
	read_SubMenu_options
else 
   echo " Not able to connect server"
fi

}

temp_cleanup(){
temp_Path=/tmp/lzswf9/lowes/ci/dev/jenkins/jobs
read -p " Enter the How many old files you want to Delete " days
#echo " changing the owner from jenkins to lwc "
#sudo -u root /home/lwc/scripts/changeperm.sh $temp_Path
#echo " Permissions are changed "
cd $temp_Path
echo " Deleteting $days days  folders in $temp_Path"
   #find . -type d -mtime +$days | xargs rm -rf
   echo $temp_Path
   #find . -type d -mtime $days -ls
   #find . -type d -mtime +$days -exec ls -ltr {} \;
   find . -type d -mtime +$days -exec rm -r {} \;
echo " Deleted order folders"

echo " Reverting the permission of the folder "
#sudo -u root  /home/lwc/scripts/changeperm-jenkins.sh $temp_Path
echo " permission are changed from lwc to jenkins"

echo " press any key to continue"
read
}

bandd_activities(){
clear

echo -e " *****************************************************"
echo -e " \t VMLNXBANDD ACTIVITIES "
echo -e " *****************************************************"
echo -e " 1. Clearing Space issues "
echo -e " 2. Go Back to Previous Menu "
echo -e " 3. EXIT "

read -p " Enter Your Option " option

case $option in
    1)temp_cleanup;;
    2)return 1;;    
    3)exit 0;;
esac
}


show_mainMenu(){
MAIN_VAR=0
clear
echo " *******************************************************************************************************"
echo -e "\t\t\t              ENVIRONMENT MENU "
echo " *******************************************************************************************************"
echo -e " DTQ Environments\tSP Environments\t\tSIT Environments\tFED Environments\tBANDD server "
echo -e " 01. DTQ1\t\t  16. DTQSP1\t\t    27. SIT1\t\t   35. DTQFED1 \t\t36. vmlnxband"
echo -e " 02. DTQ2\t\t  17. DTQSP2\t\t    28. SIT2\t\t   36. DTQFED2 "
echo -e " 03. DTQ3\t\t  18. DTQSP3\t\t    29. SIT3\t\t   37. DTQFED3 "
echo -e " 04. DTQ4\t\t  19. DTQSP4\t\t    30. SIT3STG\t\t"
echo -e " 05. DTQ5\t\t  20. DTQSP5\t\t    31. SIT4 "
echo -e " 06. DTQ6\t\t  21. DTQSP6\t\t    32. SIT4STG "
echo -e " 07. DTQ7\t\t  22. DTQSP7\t\t    33. SIT5 "
echo -e " 08. DTQ8\t\t  23. DTQSP8\t\t    34. SIT6 "
echo -e " 09. DTQ9\t\t  24. DTQSP9 "
echo -e " 10. DTQ10\t\t  25. DTQSP10"
echo -e " 11. DTQ11\t\t  26. SITSP1 "
echo -e " 12. DTQ12 "
echo -e " 13. DTQ13 "
echo -e " 14. DTQ14 "
echo -e " 15. DTQ15 "
echo -e " 99. EXIT"
}

read_mainMenu_options(){

read -p " Please Enter Your Choice " MAIN_VAR

  if ! [[ ${MAIN_VAR} =~ ^[0-9]+$ ]] ; then
	read -n1 -r -p "Invalid Option, Press any key to continue..." key
	show_mainMenu
  else if [ ${MAIN_VAR} = 36 ]; then
       bandd_activities
  else if [ ${MAIN_VAR} -eq 99 ]; then
	echo "Goodbye"
	exit 0
  else
	setEnvironment
  fi fi fi

}

while true
do 
clear
show_mainMenu
read_mainMenu_options
done

