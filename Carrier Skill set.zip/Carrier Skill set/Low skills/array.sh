#!/bin/bash


#####With out arrays
#imran="imran zareen sakinah"

#for i in $imran;do

#len="${#i}"

#echo "Length of $i is $len"
#done


##with arrays without loop

#imran=(imran zareena sakinah)

#echo ${imran[@]} | tr -s " " "\n"

##With Array and loop

#imran=(imran shaik basha)

#for i in ${imran[@]};do

#echo $i

#done

###Reverse the string

#echo "${imran[@]}" | rev

#printf "%s\n" "${imran[@]}" | rev

####storing the values in form of arrays
a=0;
for b in `cat imran.txt`
do
array[$a]=$b;
echo "array[$a] element in the file is : ${array[$a]}"
a=$(($a+1));
done
