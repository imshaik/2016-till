#!/bin/bash

CASSANDRA_HOST=vmlnxdbcass04
DATE_APPENDAGE=$(date +"%m%d%y_%H%M%S")
OUTPUT_FILE=/lowes/price_load/load_output.txt
HISTORY_FILE=/lowes/price_load/load_history.txt
LOCKED_FILE=/lowes/price_load_lock/process.lock
DATA_DIRECTORY=/lowes/price_extracts
ARCHIVE_DIRECTORY=/lowes/price_extracts/archive
TRUNCATE_SCRIPT=/lowes/price_load/truncate.cql
FILES_EXIST=false

SUCCESS_MESSAGE="$DATE_APPENDAGE price load completed successfully."
FAILURE_MESSAGE="$DATE_APPENDAGE price load failed. Please review log and reexecute."
LOCK_MESSAGE="$DATE_APPENDAGE price load executed but exited due to file lock."
EMPTY_MESSAGE="$DATE_APPENDAGE price load executed but exited due to empty load directory." 

# Checking for existing files in the data directory
for file in $DATA_DIRECTORY/*; do
	if [ ${file: -4} == ".txt" ]; then
		FILES_EXIST=true
		break
    fi
done

if [ ! -f $LOCKED_FILE ] && [ "$FILES_EXIST" = true ]; then
  touch $LOCKED_FILE
  
  # Truncating the Cassandra tables if there isn't a lock file and new files exist for loading
  /usr/bin/cqlsh -f $TRUNCATE_SCRIPT $CASSANDRA_HOST
  
  java -jar /lowes/price_load/lowes-spark-loader-0.0.3.jar $DATA_DIRECTORY $CASSANDRA_HOST '' 1000 '' '' local[*] > $OUTPUT_FILE 2>&1
  
  if [ ! -d $ARCHIVE_DIRECTORY ]; then
    mkdir $ARCHIVE_DIRECTORY
  fi

  cd $DATA_DIRECTORY
  for file in *.txt; do
    if [ $file != "*.txt" ]; then
      file_name=$DATE_APPENDAGE
      file_name+=_$file
      mv $file $file_name
      mv $file_name $ARCHIVE_DIRECTORY
    fi
  done

  if [ "$(grep -c "Job completed with status: FAILED" $OUTPUT_FILE)" -lt 1 ]; then
     echo $SUCCESS_MESSAGE >> $HISTORY_FILE
     rm $LOCKED_FILE
  else
     echo $FAILURE_MESSAGE >> $HISTORY_FILE
     rm $LOCKED_FILE
     exit 1
  fi
  
else
	if [ -f $LOCKED_FILE ]; then
		echo $LOCK_MESSAGE >> $HISTORY_FILE
	else
		echo $EMPTY_MESSAGE >> $HISTORY_FILE
	fi
fi
