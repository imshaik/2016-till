#!/bin/bash
#
# /etc/rc.d/init.d/aem6
#
#
# # of the file to the end of the tags section must begin with a #
# character. After the tags section, there should be a blank line.
# This keeps normal comments in the rest of the file from being
# mistaken for tags, should they happen to fit the pattern.>
#
# chkconfig: 35 85 15
# description: This service manages the Adobe Experience Manager java process.
# processname: aem6
# pidfile: /crx-quickstart/conf/cq.pid

# Source function library.
. /etc/rc.d/init.d/functions

SCRIPT_NAME=`basename $0`
AEM_ROOT=/lowes/crx/publish

########
BIN=${AEM_ROOT}/crx-quickstart/bin
#echo -n "Starting quickstart:" &&
sleep 3
START=${BIN}/quickstart
STOP=${BIN}/stop
STATUS="${BIN}/status"

case "$1" in
start)
echo
echo
echo -n "Starting AEM services: " &&
echo
${START}
touch /var/lock/subsys/$SCRIPT_NAME
;;
stop)
echo -n "Shutting down AEM services: "
${STOP}
rm -f /var/lock/subsys/$SCRIPT_NAME
;;
status)
${STATUS}
;;
restart)
${STOP}
${START}
;;
reload)
;;
*)
echo "Usage: $SCRIPT_NAME {start|stop|status|reload}"
exit 1
;;
esac