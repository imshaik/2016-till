var gulp = require('gulp');
var argv = require('yargs').argv;
var sftp = require('gulp-sftp');
var cleancss = require('gulp-clean-css');
var concat = require('gulp-concat');
var notify = require('gulp-notify');
var uglify = require('gulp-uglify');
var rename = require('gulp-rename');
var gutil = require('gulp-util');
var gulpif = require('gulp-if');
var less = require('less');
var through2 = require('through2');
var dir = require('node-dir');
var _ = require("lodash");
var fs = require("fs");
var shell = require('shelljs');
var execOpts = {silent: true, async: false};

require('shelljs/global');

var cdnOutputDir = __dirname + "/lowes-cq-ui/target/cdn";
var lowesMobileFirstPath = __dirname + "/lowes-cq-ui/src/main/content/jcr_root/etc/clientlibs/lowes-mobile-first";

var gulpLess = function (options) {
    // Mixes in default options.
    options = _.defaults(options || {}, {
        compress: false,
        paths: []
    });

    return through2.obj(function (file, enc, cb) {

        if (file.isNull()) {
            return cb(null, file);
        }

        if (file.isStream()) {
            return cb(new gutil.PluginError("gulpLess", "Streaming not supported"));
        }

        var str = file.contents.toString("utf8");

        // Clones the options object.
        var opts = _.defaults({}, options);

        // Injects the path of the current file.
        opts.filename = file.path;

        less.render(str, opts, function (err, css) {
            if (err) {
                // Convert the keys so PluginError can read them
                err.lineNumber = err.line;
                err.fileName = err.filename;

                // Add a better error message
                err.message = err.message + " in file " + err.fileName + " line no. " + err.lineNumber;

                return cb(new gutil.PluginError("gulpLess", err));
            } else {
                file.contents = new Buffer(css);
                file.path = gutil.replaceExtension(file.path, ".css");

                cb(null, file);
            }
        });
    });
};

gulp.task('build', function(cb) {
    var clientlibs = [];
    var processFile = function (error, content, filename, next) {
        if (error) throw error;
        if ((/#base=(.+)\s/.exec(content) === null)) {
            next();
        } else {
            var type = filename.indexOf("js.txt") > -1 ? "js" : "css",
                base = /#base=(.+)\s/.exec(content)[1],
                path = filename.replace(/\/(css|js)\.txt/, ""),
                files = content.split("\n").filter(function (value) {
                    return value !== "" && value.indexOf("#base=") === -1;
                }),
                category = /categories="\[(.+)]"/.exec(fs.readFileSync(path + "/.content.xml"))[1],
                cdnFullPath = "/clientlibs/" + category.replace(/\./g, "/") + "." + type,
                cdnDirPath = cdnFullPath.split("/").slice(0, cdnFullPath.split("/").length - 1).join("/"),
                cdnFilename = cdnFullPath.split("/").pop();


            // Make sure all the files exist
            //_.each(files, function(file){
            //    var filepath = path + "/" + base + "/" + file;
            //
            //    if (filepath.indexOf('..') === -1) {
            //        try{
            //            fs.lstatSync(filepath).isFile();
            //        }catch(e) {
            //            gutil.log(gutil.colors.red("Clientlib '"+category+"': File not found: " + filepath));
            //            exit(0);
            //        }
            //    }
            //});

            // Push a new clientlib object into the clientlibs array.
            if ((path.indexOf("commons") > -1 || path.indexOf("page") > -1) && files.length > 0) {
                clientlibs.push({
                    type: type,
                    category: category,
                    cdnFullPath: cdnFullPath,
                    cdnDirPath: cdnDirPath,
                    cdnFilename: cdnFilename,
                    path: path,
                    base: base,
                    files: files
                });
            }

            next();
        }
    };
    // Find and parse all of the lowes-mobile-first clientlibs
    dir.readFiles(lowesMobileFirstPath, {match: /(css|js)\.txt$/}, processFile, function (error) {
        if (error) throw error;
        var processed = 0;
        var proceedIfFinished = function () {
            var stream = through2.obj(function () {
                processed++;
                //console.log(processed + " of " + clientlibs.length);
                if (processed === clientlibs.length) {
                    gutil.log(gutil.colors.cyan("gulpfile: "), gutil.colors.green("Finished processing clientlibs."));
                    cb();
                }
            });
            stream.resume();
            return stream;
        };

        // Compile, concatenate, and minify each clientlib.
        _.each(clientlibs, function (clientlib) {
            gulp.src(clientlib.files.map(function (val) {
                return clientlib.path + "/" + clientlib.base + "/" + val
            }), {base: clientlib.path})
                    .pipe(gulpif(clientlib.type === "css", gulpLess({
                        paths: [clientlib.path + "/" + clientlib.base]
                    })))
                    .on("error", function (err) {
                        console.log(err.message);
                    })
                    .pipe(concat(clientlib.cdnFilename))
                    .pipe(gulp.dest(cdnOutputDir + clientlib.cdnDirPath + "/"))
                    .pipe(gulpif(clientlib.type === "js", uglify()))
                    .pipe(gulpif(clientlib.type === "css", cleancss()))
                    .pipe(rename(clientlib.cdnFilename.replace("." + clientlib.type, ".min." + clientlib.type)))
                    .pipe(gulp.dest(cdnOutputDir + clientlib.cdnDirPath + "/"))
                    .pipe(notify("Processed Clientlib: " + clientlib.category + "(" + clientlib.type.toUpperCase() + ")"))
                    .pipe(proceedIfFinished());
                    // .pipe(proceedIfFinished())
        });
    });
});

gulp.task('cdn', ['build'], function () {
    var deployAttempts = 0;
    var maxDeployAttempts = process.env.bamboo_MAX_DEPLOY_ATTEMPTS || 25;
    var versionedEnvironments = ['www','inactive','pp'];
    // Grab the environmnet/environment name from arg or environment variable
    var environmentName = argv.environmentName || process.env.bamboo_CDN_ENV_NAME;
    if (!environmentName) {
        echo('No environmentName specified. Exiting...');
        exit(1);
    }

    // Setup our deployment variables
    var lowesCqVersion = /<version>(.+)<\/version>/g.exec(fs.readFileSync("lowes-cq-ui/pom.xml"))[1].replace("-SNAPSHOT", ""),
            cdnUser = "sshacs",
            cdnHost = "lowesco.upload.akamai.com",
            cdnCpCode = (versionedEnvironments.indexOf(environmentName) > -1 ? "180073" : "538552"),
            cdnBaseEnv = (environmentName.indexOf("inactive") > -1 ? "www" : environmentName),
            cdnBasePath = "/"+cdnCpCode+"/" + cdnBaseEnv,
            cdnAppPath = "/cq/",
            cdnPathVersion = (versionedEnvironments.indexOf(environmentName) > -1 ? lowesCqVersion : "dev"),
            cdnPath = cdnBasePath + cdnAppPath + cdnPathVersion + "/",
            version_file_name = (environmentName.indexOf("inactive") > -1 ? "inactiveversion" : "version"),
            rsaKeyPath = "~/.ssh/lwc_id_rsa";

    /**
     * Deploys the lowes-cq-ui/target/cdn directory's contents to the cdn and flushes akamai.
     */
    // Create the cdn path for this version/environment as needed
    gutil.log(gutil.colors.cyan("gulpfile: "), gutil.colors.green("Creating deployment directory on the cdn:"), cdnPath);
    exec("ssh -i ~/.ssh/lwc_id_rsa " + cdnUser + "@" + cdnHost + " 'mkdir -p " + cdnPath + "'", execOpts);

    // Create the version file for this version/enviornment as needed
    fs.writeFileSync(version_file_name, cdnPathVersion);

    function deployVersion() {
        var stream = gulp.src(version_file_name)
                .pipe(sftp({
                    host: cdnHost,
                    user: cdnUser,
                    keyLocation: rsaKeyPath,
                    remotePath: cdnBasePath + cdnAppPath
                }));

        // Retry on fail
        stream.on("error", function(){
            deployVersion();
        });
    }

    function deployAssets() {
        // Deploy the assets
        ++deployAttempts;
        notify("Deploy assets to the cdn...");
        var stream = gulp.src(cdnOutputDir + "/**/*")
                .pipe(sftp({
                    host: cdnHost,
                    user: cdnUser,
                    keyLocation: rsaKeyPath,
                    remotePath: cdnPath
                }));

        var urlsToClear = [
            "http://www.lowescdn.com/" + cdnBaseEnv + cdnAppPath + cdnPathVersion + "/",
            "https://www.lowescdn.com/" + cdnBaseEnv + cdnAppPath + cdnPathVersion + "/",
            "https://www.lowescdn.com/" + cdnBaseEnv + cdnAppPath  + "inactiveversion",
            "https://www.lowescdn.com/" + cdnBaseEnv + cdnAppPath + "version"
        ];

        // Flush Akamai
        stream.on("finish", function () {
            gutil.log(gutil.colors.cyan("gulpfile: "), gutil.colors.green("Initiating Akamai flush: "), JSON.stringify(urlsToClear));
            exec("curl -s -k https://api.ccu.akamai.com/ccu/v2/queues/default -H 'Content-Type:application/json' -d '{\"type\":\"arl\",\"action\":\"invalidate\",\"objects\":"+JSON.stringify(urlsToClear)+"}' -u bamboo:lowes348");
            // CDN Symlink for Client Assets Project
            gutil.log("gulpfile: ".cyan, 'Updating the stable symlink to the latest version'.green);
            gutil.log("shellJs/ssh: ".cyan, shell.exec(["ssh -i ~/.ssh/lwc_id_rsa ", cdnUser + "@" + cdnHost, " 'rm -rv /" + cdnCpCode + "/" + cdnBaseEnv + "/cq/stable'"].join(""), execOpts).output.replace(/\n/, "").green);
            gutil.log("shellJs/ssh: ".cyan, shell.exec(["ssh -i ~/.ssh/lwc_id_rsa ", cdnUser + "@" + cdnHost, " 'ln -sv /" + cdnCpCode + "/" + cdnBaseEnv + "/cq/" + cdnPathVersion + " /" + cdnCpCode + "/" + cdnBaseEnv + "/cq/stable'"].join(""), execOpts).output.replace(/\n/, "").green);
        });

        // Retry on fail
        stream.on("error", function () {
            if (deployAttempts < maxDeployAttempts) {
                gutil.log("gulpfile: ".cyan, "Re-attempt #("+deployAttempts+") to deploy to CDN".red);
                deployAssets();
            } else {
                gutil.log("gulpfile: ".cyan, "Max attempts ("+maxDeployAttempts+") to deploy to CDN reached, failed to deploy.".red);
                shell.exit(1);
            }
        });
    }

    deployVersion();
    deployAssets();
});

// The default task (called when you run `gulp` from cli)
gulp.task('default', ['build']);